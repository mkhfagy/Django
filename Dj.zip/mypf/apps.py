from django.apps import AppConfig


class MypfConfig(AppConfig):
    name = 'mypf'
